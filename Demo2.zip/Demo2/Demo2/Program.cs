﻿using System;

namespace Demo2
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.GetReadyForSchool();
        }
        public void GetReadyForSchool()
          {
              DOAllRequiredWorks(new Action[]{
                 WakeUpEarly,
                 DoBrush,
                 DoBath,
                 WearUniform,
                 GetinToSchoolBus
                 
            });
              Console.ReadKey();
         }

        private void WakeUpEarly()
        {
            Console.WriteLine("Wake Up Early");
        }
        private void DoBrush()
        {
            Console.WriteLine("Do Brush");
        }
        private void DoBath()
        {
            Console.WriteLine("Do Bath");
        }
        private void WearUniform()
        {
            Console.WriteLine("Wear uniform and comb hair");
        }
        private void GetinToSchoolBus()
        {
            Console.WriteLine("Get in to school bus");
        }

        public void DOAllRequiredWorks(params Action[] actions)
        {
            try
            {
                foreach (var a in actions)
                    a();                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return;
            }
        }
    }
}
 